/*
Copyright 2015 Google Inc. All rights reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

#ifndef _FILE_RESOURCE_H_
#define _FILE_RESOURCE_H_

#include <stdio.h>
#include <string>

class FileResource {
 public:
  // Mode follows the standard (eg. "wb", "r").
  FileResource(const std::string &filename, const std::string &mode);
  ~FileResource();

  // Opens a file with the specified mode. Returns false if it fails.
  bool Get();

  FILE *fp() { return fp_; }

  bool eof() const {
    return feof(fp_) != 0;
  }

 private:
  std::string filename_;
  std::string mode_;
  FILE *fp_;
};

#endif  // _FILE_RESOURCE_H_
